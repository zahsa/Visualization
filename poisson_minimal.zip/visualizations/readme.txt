This is the example code to generate the simplified images as described in Section 3.1. and Figure 2 in Zhou et al ICLR'15.
